
<!--	<div class="footerMain">
		<div class="content">
			<div class="footer-grids">
				<div class="footer one">
					<div class="clear"></div>
				</div>
				<div class="footer two">
					<h3>Keep Connected</h3>
					<ul>
						<li><a class="fb" href="https://www.facebook.com/nikhitha.alokam"><i></i>Like us on Facebook</a></li>
					</ul>
				</div>
				<div class="footer three">
					<h3>Contact Information</h3>
					<ul>
						<li>7075913589</li>
						<a style="margin-top: 10px;margin-left: 5px;margin-right: 5px" href="https://github.com/tanmayee-07/SE-Tutor-Finder-App"><img src="https://cdn.icon-icons.com/icons2/2351/PNG/512/logo_github_icon_143196.png" title="Photography" width="42" height="42" style="border-radius: 50%;"></a>
						<a style="margin-top: 10px;margin-left: 5px;margin-right: 5px" href="https://www.linkedin.com/in/tanmayee-choudhury-56154b1b3/"><img src="https://i.pinimg.com/originals/c1/17/25/c117254de6fbc71a924865a5ddee1faf.png" title="IT Solution" style="border-radius: 50%;" width="42" height="42"></a>
						<a style="margin-top: 10px;margin-left: 5px;margin-right: 5px" href="https://twitter.com/twitter?lang=en"><img src="image/twitter-logo.png" title="Tution" style="border-radius: 50%;" width="40" height="42"></a>

					</ul>
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div>
-->
